package test.newOAuth;

import com.docusign.esign.api.EnvelopesApi;
import com.docusign.esign.client.ApiClient;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.client.auth.OAuth;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DsNewAuth {
    private static final long TOKEN_EXPIRATION_IN_SECONDS = 3600;
    private static final int FROM_DATE_OFFSET_DAYS = 30;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd");

    public static void main(String[] args) {
        List<String> scopes = new ArrayList<String>();
        scopes.add("signature");

        File privateKeyFile = new File("privateKey.txt");
        FileInputStream fin;
        byte privateKeyFileContent[] = null;
        OAuth.OAuthToken oAuthToken;

        try {
            // create FileInputStream object
            fin = new FileInputStream(privateKeyFile);

            privateKeyFileContent = new byte[(int)privateKeyFile.length()];

            // Reads up to certain bytes of data from this input stream into an array of bytes.
            fin.read(privateKeyFileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }

        ApiClient apiClient = new ApiClient();
        apiClient.setBasePath("https://demo.docusign.net/restapi");
        apiClient.setOAuthBasePath("account-d.docusign.com");
        try {
            oAuthToken = apiClient.requestJWTUserToken(
                    Config.CLIENT_ID,
                    Config.USER_ID,
                    scopes,
                    privateKeyFileContent,
                    TOKEN_EXPIRATION_IN_SECONDS);
            apiClient.addDefaultHeader("Authorization", "Bearer " + oAuthToken.getAccessToken());
            apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());

            EnvelopesApi envelopesApi = new EnvelopesApi(apiClient);
            EnvelopesApi.ListStatusChangesOptions options = envelopesApi.new ListStatusChangesOptions();
            LocalDate date = LocalDate.now().minusDays(FROM_DATE_OFFSET_DAYS);
            options.setFromDate(DATE_FORMATTER.format(date));

            var result = envelopesApi.listStatusChanges(Config.ACCOUNT_ID, options);
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
