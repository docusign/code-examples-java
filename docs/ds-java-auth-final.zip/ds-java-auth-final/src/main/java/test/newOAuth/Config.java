package test.newOAuth;

public class Config {
    public static final String CLIENT_ID = "xxxx";
    public static final String USER_ID = "xxxx";
    public static final String ACCOUNT_ID = "xxxx";
}
